$('#navbar').affix({
    offset: { top: $('#banner').height() }   
});